#!/bin/sh
cd bin
for file in BingClaw5.6.1
do
  if test -r $file
  then
    rm $file
  fi
done
# make -f Makefile.modules
# make -f Makefile.nonmodules
# make -f Makefile
