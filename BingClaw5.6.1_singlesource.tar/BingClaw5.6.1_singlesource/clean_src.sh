#!/bin/sh
cd src
for file in *.a *.mod
do
  if test -r $file
  then
    rm $file
  fi
done
# make -f Makefile.modules
# make -f Makefile.nonmodules
# make -f Makefile
