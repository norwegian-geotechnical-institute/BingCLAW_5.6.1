#!/bin/sh
# Compile BingClaw5.6.1 using the following sequence of commands
make -f Makefile.modules
make -f Makefile.nonmodules
make BingClaw5.6.1
